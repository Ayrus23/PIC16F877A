/*
 * NAME : SURYAPRAKASH M
 * DATE : 13/01/2024
 * DESCRPTION : A04-Implement a point brightness control
 */

#include <xc.h>
#include "main.h"
#include "timers.h"
#include "digital_keypad.h"
#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT enabled)

extern int flag;
void software_pwm(unsigned char key)
{
    static unsigned long int period = 100, loop_counter = 0, wait = 0, duty_cycle = 50;            
    while (1) 
    {        
        /*checking if timer 0 interrupt flag is 0*/
        /*10%-LED blinking*/
        if (TMR0IE == 0)
        {
            duty_cycle = 10;
        }
        /*reading key pressed*/
        key = read_digital_keypad(LEVEL);
        
        if (wait-- == 0)
        {

            wait = 1000;

            if (key == SW1)
            {
                /*changing duty cycle to 100 on key press*/
                  duty_cycle=100;
                  
                  TMR0IE = 1;
                  
            }
            
        }
        /*50%-LED Blinking*/
        if (loop_counter < duty_cycle)
        {
            LED1 = 1;
        }
        else if (loop_counter > duty_cycle)
        {
            LED1 = 0;
        }
        if(loop_counter++ == period)
        {
            loop_counter = 0;
        }
        
    }
}
void init_config(void) {
    	
    LED_ARRAY = 0x00;    // off allLED
	LED_ARRAY_DDR = 0x00;
    
    init_digital_keypad();
    init_timer0();
    
    /*Global interrupt enable*/
    GIE = 1;    
}
void main(void) {
    init_config();
    unsigned char key;
    
    while (1) {
        
        key = read_digital_keypad(LEVEL);       
        software_pwm(key);       
    }
    return;
}

    
