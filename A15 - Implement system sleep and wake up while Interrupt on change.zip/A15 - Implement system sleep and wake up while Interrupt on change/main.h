

#ifndef MAIN_H
#define	MAIN_H

#define LED1                RB7


#define LED_ARRAY1          PORTB
#define LED_ARRAY2          PORTD
#define LED_ARRAY_DDR       TRISB
#define LED_ARRAY1_DDR7     TRISB7

#endif	/* MAIN_H */

