/* 
 * File:   main.h
 */

#ifndef MAIN_H
#define	MAIN_H

#define OFF              0x00

#define  LED_ARRAY_1      PORTD
#define  LED_ARRAY_1_DDR  TRISD
void glow_on_press(unsigned char key);

#endif	/* MAIN_H */

