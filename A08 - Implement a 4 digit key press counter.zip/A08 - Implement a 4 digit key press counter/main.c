/*
 * Name: SURYAPRAKSAH M
 * Date : 08/01/2024
 * Description: A08 - Implement a 4 digit key press counter
 */

#include <xc.h>
#include "digital_keypad.h"
#include "ssd.h"
#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT disabled)
#define SW_WAIT     200 

unsigned char key;
unsigned char ssd[MAX_SSD_CNT];
unsigned char digit[] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE}; 
static unsigned  long int count = 0,flag = 1, wait = 0 , sw_count = 0; 
unsigned char eeprom_test(unsigned char key)
{
    while(1)
    {
        
        key = read_digital_keypad(LEVEL);
               
        if (key == SW2)
        {
            /*writing every digit in EEprom*/
            eeprom_write(0x03, (count % 10));
            eeprom_write(0x02, ((count % 100)/10));
            eeprom_write(0x01, ((count % 1000)/100));
            eeprom_write(0x00, (count / 1000));
        }          

        //count upto 9999 on every key press(DKP3).
        //Once count exceeds 9999 lets Roll back to 0.
        if (key == SW1)
        {                                                   
            if(flag)                                       
            {                                                         
                if (count++ == 9999)
                {
                    count = 0;
                }
                flag = 0;                            
            }                             
            else               
            {                  
                sw_count--;                 
            }

        }                      
        else            
        {
            flag = 1;                   
        }       
       /*          
        *   If switch pressed for less than 2sec,           
        *  Calculating each digit of a 4 digit number.          
        *  Else reset count to 0 to display all 0 on SSD's.          
        *  Display on SSD using display function.           
        */                               
        if(sw_count > 0)          
        {                         
            if(wait++ == 25)               
            {   
                wait = 0;   
                ssd[3] = digit[(count % 10)];                                     
                ssd[2] = digit[(count % 100) / 10];                                   
                ssd[1] = digit[(count % 1000) / 100];                                    
                ssd[0] = digit[(count / 1000)];                                  

            }

        }                      
        else           
        {                               
            sw_count = SW_WAIT;                          
            count = 0;                     
        }                   
        if( count >= 9999 )           
        {
            while(1);           
        }       
        display(ssd);         
    }

}   

static void init_config(void) {
    init_digital_keypad();
    init_ssd(); 
}

void main(void) {

    init_config();                       
    while (1) 
    {      
        count = eeprom_test(key);

    }
    return;
}
