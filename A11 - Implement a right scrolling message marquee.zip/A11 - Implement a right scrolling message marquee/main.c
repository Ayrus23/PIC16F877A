/*
 * NAME: SURYAPRAKASH M
 * DATE: 3/01/2024
 * DESCRPTION: A11 - Implement a right scrolling message marquee
 */

#include <xc.h>
#include "clcd.h"

#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT disabled)

static void init_config(void) {
    
    init_clcd();
}

void main(void) {
    
    init_config();
    unsigned char temp;
    unsigned int wait;
    char message[] = "GOOD_MORNING____";
     
    while (1) 
    {
        /*Right scrolling*/           
        clcd_print("Right Scrolling",LINE1(0));
        /*right scrolling logic*/                          
        temp = message[15];          
        for(int i = 15 ; i > 0 ; i--)          
        {              
            message[i] = message[i - 1];	          
        }          
        message[0] = temp; 
        /*display the message in 2nd line first position*/
        clcd_print(message, LINE2(0));          
        // non-blocking delay         
        if(wait++ == 50000)          
        {
                wait=0;           
        }      
    }
    return;
}

